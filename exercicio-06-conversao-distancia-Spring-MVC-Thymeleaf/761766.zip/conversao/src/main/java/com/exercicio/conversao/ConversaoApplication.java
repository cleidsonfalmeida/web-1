package com.exercicio.conversao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConversaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConversaoApplication.class, args);
	}

}
