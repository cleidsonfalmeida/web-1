package com.exercicio.conversao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
